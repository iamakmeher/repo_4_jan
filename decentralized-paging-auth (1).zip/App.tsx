import React, { useState, useEffect } from 'react';
import Hero from './components/Hero';
import WalletConnect from './components/WalletConnect';
import AuthActions from './components/AuthActions';
import StatusPanel from './components/StatusPanel';
import ProgressSteps from './components/ProgressSteps';
import Footer from './components/Footer';
import { AuthStatus, WalletState, AuthResult } from './types';
import * as Web3Service from './services/web3Service';

function App() {
  const [wallet, setWallet] = useState<WalletState>({
    isConnected: false,
    address: null,
    chainId: null,
  });

  const [authStatus, setAuthStatus] = useState<AuthStatus>(AuthStatus.IDLE);
  const [authResult, setAuthResult] = useState<AuthResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Setup listeners for MetaMask account changes
  useEffect(() => {
    if (Web3Service.checkWalletInstalled()) {
      Web3Service.subscribeToAccountChanges(async (accounts) => {
        if (accounts.length > 0) {
          const address = accounts[0];
          setWallet(prev => ({ ...prev, isConnected: true, address }));
          
          // Reset auth state but check registration
          setAuthStatus(AuthStatus.IDLE);
          setErrorMsg(null);
          
          const isRegistered = await Web3Service.checkUserRegistration(address);
          if (isRegistered) {
            setAuthResult({
              message: "Welcome back",
              isAuthenticated: false,
              userRegistered: true
            });
          } else {
            setAuthResult(null);
          }
        } else {
          // User disconnected
          setWallet({ isConnected: false, address: null, chainId: null });
          setAuthResult(null);
        }
      });
    }
  }, []);

  const handleConnect = async () => {
    try {
      setAuthStatus(AuthStatus.LOADING);
      setErrorMsg(null);
      
      const address = await Web3Service.connectWallet();
      
      setWallet({
        isConnected: true,
        address,
        chainId: 1, // Defaulting for display
      });

      // Check "Backend" for existing registration
      const isRegistered = await Web3Service.checkUserRegistration(address);
      if (isRegistered) {
        setAuthResult({
          message: "Welcome back",
          isAuthenticated: false,
          userRegistered: true
        });
      }

      setAuthStatus(AuthStatus.IDLE);
    } catch (err: any) {
      console.error(err);
      setAuthStatus(AuthStatus.ERROR);
      setErrorMsg(err.message || "Failed to connect wallet.");
    }
  };

  const handleRegister = async () => {
    if (!wallet.address) return;
    
    setAuthStatus(AuthStatus.LOADING);
    setAuthResult(null);
    setErrorMsg(null);

    try {
      const result = await Web3Service.registerUser(wallet.address);
      setAuthResult(result);
      setAuthStatus(AuthStatus.SUCCESS);
    } catch (err: any) {
      setAuthStatus(AuthStatus.ERROR);
      setErrorMsg(err.message || "Registration failed.");
    }
  };

  const handleAuthenticate = async () => {
    if (!wallet.address) return;

    setAuthStatus(AuthStatus.LOADING);
    // Keep previous state (like registration) if possible, but we generally reset result to show loading
    // However, if we fail, we might want to remember they were registered.
    // For simplicity, we reset to show fresh status.
    setAuthResult(null);
    setErrorMsg(null);

    try {
      const result = await Web3Service.authenticateUser(wallet.address);
      setAuthResult(result);
      setAuthStatus(AuthStatus.SUCCESS);
    } catch (err: any) {
      setAuthStatus(AuthStatus.ERROR);
      setErrorMsg(err.message || "Authentication failed.");
      
      // If auth failed, check if they are at least registered to restore that state
      const isRegistered = await Web3Service.checkUserRegistration(wallet.address);
      if (isRegistered) {
        setAuthResult({
            message: "Welcome back",
            isAuthenticated: false,
            userRegistered: true
        });
      }
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden font-sans selection:bg-neonCyan/30 text-slate-200">
      
      {/* Background Gradients */}
      <div className="fixed inset-0 bg-[#0B1121] z-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-neonBlue/20 rounded-full blur-[128px] opacity-40 animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-neonPurple/10 rounded-full blur-[128px] opacity-40"></div>
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150"></div>
      </div>

      <main className="relative z-10 max-w-4xl mx-auto px-4 py-12 md:py-20 flex flex-col items-center">
        
        <Hero />
        
        <ProgressSteps isConnected={wallet.isConnected} result={authResult} />

        <div className="w-full max-w-lg">
          <WalletConnect 
            walletState={wallet} 
            onConnect={handleConnect} 
            isLoading={authStatus === AuthStatus.LOADING && !wallet.isConnected}
          />
          
          <AuthActions 
            isConnected={wallet.isConnected} 
            onRegister={handleRegister} 
            onAuthenticate={handleAuthenticate}
            status={authStatus}
          />

          <StatusPanel 
            status={authStatus} 
            result={authResult} 
            error={errorMsg} 
          />
        </div>

        <Footer />
      </main>
    </div>
  );
}

export default App;