import React from 'react';
import { UserPlus, ShieldCheck } from 'lucide-react';
import { AuthStatus } from '../types';
import Card from './Card';

interface AuthActionsProps {
  isConnected: boolean;
  onRegister: () => void;
  onAuthenticate: () => void;
  status: AuthStatus;
}

const AuthActions: React.FC<AuthActionsProps> = ({ isConnected, onRegister, onAuthenticate, status }) => {
  const isLoading = status === AuthStatus.LOADING;

  return (
    <Card className="mb-8 border-t-2 border-t-neonPurple/20" title="Actions">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Register Button */}
        <button
          onClick={onRegister}
          disabled={!isConnected || isLoading}
          className={`
            relative p-6 rounded-xl border border-white/10 transition-all duration-300 text-left group
            ${!isConnected 
              ? 'opacity-40 cursor-not-allowed bg-gray-900' 
              : 'hover:border-neonPurple/50 hover:bg-white/5 cursor-pointer bg-white/5'}
          `}
        >
          <div className="flex items-start justify-between mb-4">
            <div className={`p-3 rounded-lg ${isConnected ? 'bg-neonPurple/20 text-neonPurple' : 'bg-gray-800 text-gray-500'}`}>
              <UserPlus size={24} />
            </div>
            {isLoading && <span className="text-xs text-neonPurple animate-pulse">Processing...</span>}
          </div>
          <h4 className="text-lg font-bold text-white mb-1 group-hover:text-neonPurple transition-colors">Register User</h4>
          <p className="text-sm text-slate-400">Create a new identity on the blockchain registry.</p>
        </button>

        {/* Authenticate Button */}
        <button
          onClick={onAuthenticate}
          disabled={!isConnected || isLoading}
          className={`
            relative p-6 rounded-xl border border-white/10 transition-all duration-300 text-left group
            ${!isConnected 
              ? 'opacity-40 cursor-not-allowed bg-gray-900' 
              : 'hover:border-neonCyan/50 hover:bg-white/5 cursor-pointer bg-white/5'}
          `}
        >
          <div className="flex items-start justify-between mb-4">
            <div className={`p-3 rounded-lg ${isConnected ? 'bg-neonCyan/20 text-neonCyan' : 'bg-gray-800 text-gray-500'}`}>
              <ShieldCheck size={24} />
            </div>
            {isLoading && <span className="text-xs text-neonCyan animate-pulse">Processing...</span>}
          </div>
          <h4 className="text-lg font-bold text-white mb-1 group-hover:text-neonCyan transition-colors">Authenticate User</h4>
          <p className="text-sm text-slate-400">Verify your identity against the smart contract.</p>
        </button>
      </div>
    </Card>
  );
};

export default AuthActions;