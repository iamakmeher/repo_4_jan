import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '', title }) => {
  return (
    <div className={`glass-card rounded-2xl p-6 shadow-2xl relative overflow-hidden ${className}`}>
      {/* Subtle glow effect in the corner */}
      <div className="absolute -top-10 -right-10 w-32 h-32 bg-neonCyan/10 rounded-full blur-3xl pointer-events-none"></div>
      
      {title && (
        <h3 className="text-xl font-bold text-white mb-4 border-b border-white/10 pb-2">
          {title}
        </h3>
      )}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
};

export default Card;