import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="mt-12 pb-8 text-center relative z-10">
      <div className="w-24 h-1 bg-gradient-to-r from-transparent via-neonCyan to-transparent mx-auto mb-6 opacity-50"></div>
      <p className="text-slate-500 text-sm font-light tracking-widest">
        POWERED BY ETHEREUM • SMART CONTRACTS • WEB3
      </p>
      <p className="text-slate-700 text-xs mt-2">
        Decentralized Paging Protocol 
      </p>
    </footer>
  );
};

export default Footer;