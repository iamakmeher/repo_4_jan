import React from 'react';
import { Blocks } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="text-center mb-12 relative z-10">
      <div className="flex justify-center mb-6">
        <div className="p-4 bg-white/5 rounded-full border border-white/10 shadow-[0_0_15px_rgba(6,182,212,0.3)] animate-pulse">
          <Blocks size={48} className="text-neonCyan" />
        </div>
      </div>
      <h1 className="text-4xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-neonCyan via-neonBlue to-neonPurple mb-4 drop-shadow-sm">
        Decentralized Paging Auth
      </h1>
      <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto font-light tracking-wide">
        Secure, transparent, blockchain-based identity verification system for the decentralized web.
      </p>
    </div>
  );
};

export default Hero;