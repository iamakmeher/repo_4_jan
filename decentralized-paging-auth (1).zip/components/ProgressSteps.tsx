import React from 'react';
import { Wallet, UserPlus, Fingerprint } from 'lucide-react';
import { AuthResult } from '../types';

interface ProgressStepsProps {
  isConnected: boolean;
  result: AuthResult | null;
}

const ProgressSteps: React.FC<ProgressStepsProps> = ({ isConnected, result }) => {
  const steps = [
    {
      id: 1,
      label: 'Wallet Connected',
      icon: Wallet,
      active: isConnected,
      completed: isConnected,
    },
    {
      id: 2,
      label: 'User Registered',
      icon: UserPlus,
      active: isConnected && !!result?.userRegistered,
      completed: isConnected && !!result?.userRegistered,
    },
    {
      id: 3,
      label: 'Verified',
      icon: Fingerprint,
      active: isConnected && !!result?.isAuthenticated,
      completed: isConnected && !!result?.isAuthenticated,
    },
  ];

  return (
    <div className="w-full max-w-3xl mx-auto mb-12">
      <div className="flex justify-between relative">
        {/* Connection Line Background */}
        <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-800 -translate-y-1/2 rounded-full z-0"></div>
        
        {/* Active Line Progress - Simplified logic for visuals */}
        <div 
            className="absolute top-1/2 left-0 h-1 bg-gradient-to-r from-neonBlue to-neonCyan -translate-y-1/2 rounded-full z-0 transition-all duration-700 ease-out"
            style={{ width: result?.isAuthenticated ? '100%' : result?.userRegistered ? '50%' : isConnected ? '10%' : '0%' }}
        ></div>

        {steps.map((step, index) => {
          const Icon = step.icon;
          const isActive = step.active;
          const isCompleted = step.completed;

          return (
            <div key={step.id} className="relative z-10 flex flex-col items-center group">
              <div 
                className={`
                  w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-500
                  ${isActive || isCompleted 
                    ? 'bg-slate-900 border-neonCyan text-neonCyan shadow-[0_0_15px_rgba(6,182,212,0.4)] scale-110' 
                    : 'bg-slate-900 border-gray-700 text-gray-600'}
                `}
              >
                <Icon size={20} />
              </div>
              <span 
                className={`
                  mt-3 text-xs md:text-sm font-medium tracking-wide transition-colors duration-300
                  ${isActive || isCompleted ? 'text-neonCyan' : 'text-gray-600'}
                `}
              >
                {step.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProgressSteps;