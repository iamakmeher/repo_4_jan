import React from 'react';
import { CheckCircle2, XCircle, AlertCircle, Lock } from 'lucide-react';
import { AuthResult, AuthStatus } from '../types';
import Card from './Card';

interface StatusPanelProps {
  status: AuthStatus;
  result: AuthResult | null;
  error: string | null;
}

const StatusPanel: React.FC<StatusPanelProps> = ({ status, result, error }) => {
  if (status === AuthStatus.IDLE) return null;

  let content;
  let borderColor = 'border-t-gray-700';
  let icon = <AlertCircle size={32} className="text-gray-400" />;
  let title = 'Processing...';

  if (status === AuthStatus.LOADING) {
    borderColor = 'border-t-yellow-500';
    icon = <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-500"></div>;
    title = 'Transaction Pending';
    content = <p className="text-yellow-200/80">Waiting for blockchain confirmation...</p>;
  } else if (status === AuthStatus.SUCCESS && result) {
    borderColor = 'border-t-green-500';
    icon = <CheckCircle2 size={32} className="text-green-500 shadow-[0_0_15px_rgba(34,197,94,0.4)] rounded-full" />;
    title = result.message;
    content = (
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm border-b border-white/5 pb-2">
          <span className="text-slate-400">Status</span>
          <span className="text-green-400 font-bold">Confirmed</span>
        </div>
        <div className="flex items-center justify-between text-sm border-b border-white/5 pb-2">
          <span className="text-slate-400">Authenticated</span>
          <span className={`font-mono ${result.isAuthenticated ? 'text-neonCyan' : 'text-slate-500'}`}>
            {result.isAuthenticated ? 'TRUE' : 'FALSE'}
          </span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-400">Timestamp</span>
          <span className="text-xs text-slate-500 font-mono">{new Date().toLocaleTimeString()}</span>
        </div>
      </div>
    );
  } else if (status === AuthStatus.ERROR) {
    borderColor = 'border-t-red-500';
    icon = <XCircle size={32} className="text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.4)] rounded-full" />;
    // Check if it's a connection cancellation or a general error
    title = error?.includes('Metamask wallet not connected') ? 'Connection Cancelled' : 'Operation Failed';
    content = <p className="text-red-300/80">{error || "An unknown error occurred"}</p>;
  }

  return (
    <Card className={`mb-8 border-t-4 ${borderColor} transition-all duration-500`}>
      <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
        <div className="flex-shrink-0 mt-1">
          {icon}
        </div>
        <div className="flex-grow w-full text-center md:text-left">
          <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
          <div className="bg-black/20 rounded-lg p-4 border border-white/5">
            {content}
          </div>
        </div>
        {status === AuthStatus.SUCCESS && result?.isAuthenticated && (
             <div className="hidden md:flex flex-col items-center justify-center p-4 bg-neonCyan/10 rounded-lg border border-neonCyan/20">
                <Lock className="text-neonCyan mb-2" size={24} />
                <span className="text-xs text-neonCyan font-bold tracking-wider">SECURE</span>
             </div>
        )}
      </div>
    </Card>
  );
};

export default StatusPanel;