import React from 'react';
import { Wallet, Link, Unplug } from 'lucide-react';
import { WalletState } from '../types';
import Card from './Card';

interface WalletConnectProps {
  walletState: WalletState;
  onConnect: () => void;
  isLoading: boolean;
}

const WalletConnect: React.FC<WalletConnectProps> = ({ walletState, onConnect, isLoading }) => {
  return (
    <Card className="mb-8 border-t-2 border-t-neonCyan/20">
      <div className="flex flex-col items-center justify-center space-y-6">
        <div className="flex items-center space-x-3 mb-2">
          <div className={`w-3 h-3 rounded-full ${walletState.isConnected ? 'bg-green-500 shadow-[0_0_10px_#22c55e]' : 'bg-red-500 shadow-[0_0_10px_#ef4444]'}`}></div>
          <span className="text-sm uppercase tracking-widest text-slate-400 font-semibold">
            {walletState.isConnected ? 'Wallet Connected' : 'Not Connected'}
          </span>
        </div>

        {walletState.isConnected && walletState.address ? (
          <div className="bg-black/40 px-6 py-3 rounded-full border border-neonCyan/30 text-neonCyan font-mono shadow-inner flex items-center gap-2">
            <Link size={16} />
            {walletState.address.substring(0, 6)}...{walletState.address.substring(walletState.address.length - 4)}
          </div>
        ) : (
          <button
            onClick={onConnect}
            disabled={isLoading}
            className="group relative px-8 py-4 bg-gradient-to-r from-cyan-600 to-blue-700 rounded-lg text-white font-bold text-lg shadow-lg hover:shadow-cyan-500/30 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden"
          >
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
            <div className="flex items-center gap-3 relative z-10">
              {isLoading ? (
                <span className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></span>
              ) : (
                <Wallet size={20} />
              )}
              {isLoading ? 'Connecting...' : 'Connect Wallet'}
            </div>
          </button>
        )}
        
        <p className="text-slate-500 text-xs text-center max-w-sm">
          Connect your Web3 provider (MetaMask, etc.) to interact with the decentralized paging registry.
        </p>
      </div>
    </Card>
  );
};

export default WalletConnect;