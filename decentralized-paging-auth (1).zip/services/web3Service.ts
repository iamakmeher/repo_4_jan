import { AuthResult } from '../types';

/**
 * WEB3 SERVICE (MetaMask Integration & Local Backend)
 * 
 * Interacts directly with the injected window.ethereum provider.
 * Uses cryptographic signatures (personal_sign) to verify identity.
 * 
 * BACKEND SIMULATION:
 * Uses localStorage to persist registered users, mimicking a database 
 * or smart contract registry that survives page reloads.
 */

const DB_KEY = 'dpa_registered_users';

// Helper to get the "Database"
const getRegistry = (): Set<string> => {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) {
      return new Set(JSON.parse(raw));
    }
  } catch (e) {
    console.error("Failed to read from local backend", e);
  }
  // Default demo data if empty
  return new Set(["0x71c7656ec7ab88b098defb751b7401b5f6d8976f"]);
};

// Helper to save to "Database"
const saveToRegistry = (address: string) => {
  const db = getRegistry();
  db.add(address.toLowerCase());
  localStorage.setItem(DB_KEY, JSON.stringify(Array.from(db)));
};

export const checkWalletInstalled = (): boolean => {
  return typeof window !== 'undefined' && !!window.ethereum;
};

export const connectWallet = async (): Promise<string> => {
  if (!checkWalletInstalled()) {
    throw new Error("MetaMask is not installed. Please install it to use this app.");
  }

  try {
    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
    if (!accounts || accounts.length === 0) {
      throw new Error("No accounts found.");
    }
    return accounts[0];
  } catch (error: any) {
    if (error.code === 4001) {
      // User rejected the connection request
      throw new Error("Metamask wallet not connected");
    }
    throw error;
  }
};

export const checkUserRegistration = async (address: string): Promise<boolean> => {
  const db = getRegistry();
  return db.has(address.toLowerCase());
};

export const registerUser = async (address: string): Promise<AuthResult> => {
  if (!checkWalletInstalled()) throw new Error("Wallet provider not found.");

  const normalizedAddr = address.toLowerCase();
  const db = getRegistry();

  // 1. Check if already registered (Backend check)
  if (db.has(normalizedAddr)) {
    throw new Error("User address is already registered in the registry.");
  }

  try {
    // 2. Request Cryptographic Signature to prove ownership
    const message = `Register Identity for Decentralized Paging\n\nUser: ${address}\nTimestamp: ${Date.now()}`;
    
    await window.ethereum.request({
      method: 'personal_sign',
      params: [message, address],
    });

    // 3. Update "Backend"
    saveToRegistry(normalizedAddr);

    return {
      message: "Identity Verified & Registered",
      isAuthenticated: false,
      userRegistered: true,
      timestamp: new Date().toISOString()
    };
  } catch (error: any) {
    if (error.code === 4001) {
      throw new Error("User rejected the registration signature.");
    }
    throw new Error("Registration failed: " + (error.message || "Unknown error"));
  }
};

export const authenticateUser = async (address: string): Promise<AuthResult> => {
  if (!checkWalletInstalled()) throw new Error("Wallet provider not found.");

  const normalizedAddr = address.toLowerCase();
  const db = getRegistry();

  try {
    // 1. Request Cryptographic Signature for Login (SIWE style)
    const message = `Authenticate Access\n\nUser: ${address}\nNonce: ${Math.floor(Math.random() * 1000000)}`;
    
    await window.ethereum.request({
      method: 'personal_sign',
      params: [message, address],
    });

    // 2. Validate against "Backend"
    if (db.has(normalizedAddr)) {
      return {
        message: "Authentication Verified",
        isAuthenticated: true,
        userRegistered: true,
        timestamp: new Date().toISOString()
      };
    } else {
      throw new Error("Authentication Failed: User not found in registry. Please register first.");
    }
  } catch (error: any) {
    if (error.code === 4001) {
      throw new Error("User rejected the authentication signature.");
    }
    throw error;
  }
};

// Helper to listen for account changes
export const subscribeToAccountChanges = (callback: (accounts: string[]) => void) => {
  if (checkWalletInstalled()) {
    window.ethereum.on('accountsChanged', callback);
  }
};