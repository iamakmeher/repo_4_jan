export enum AuthStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}

export interface WalletState {
  isConnected: boolean;
  address: string | null;
  chainId: number | null;
}

export interface AuthResult {
  message: string;
  isAuthenticated: boolean;
  userRegistered: boolean;
  timestamp?: string;
}

export type ProgressStep = 'WALLET' | 'REGISTER' | 'AUTH';

declare global {
  interface Window {
    ethereum: any;
  }
}